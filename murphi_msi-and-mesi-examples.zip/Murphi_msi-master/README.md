Murphi_msi
==========

Cache Coherence Protocol MSI described in Murphi
